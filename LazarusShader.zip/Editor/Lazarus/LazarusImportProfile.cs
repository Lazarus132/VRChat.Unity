using UnityEngine;

[CreateAssetMenu(menuName = "Lazarus/Import Profile", fileName = "NewLazarusImportProfile")]
public class LazarusImportProfile : ScriptableObject
{
    public string profileName = "New Profile";
    public Material defaultMaterial;
    public Shader targetShader;
    public bool createPrefabs = true;
    public string prefabFolder = "Assets/LazarusPrefabs";
}
