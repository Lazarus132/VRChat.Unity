bl_info = {
    "name": "Lazarus Multi FBX Exporter + Shader Info",
    "author": "Lazarus",
    "version": (1, 4, 0),
    "blender": (4, 4, 0),
    "location": "3D View > Sidebar > Lazarus",
    "description": "Exports each selected object as FBX with textures and shader info as ZIP",
    "category": "Import-Export",
}

import bpy
import os
import shutil
import zipfile
from bpy.types import Operator, Panel
from bpy.props import StringProperty, BoolProperty


class LAZARUS_OT_export_each_as_zip(Operator):
    bl_idname = "export_scene.lazarus_multi_zip_shader"
    bl_label = "Export Each Object as FBX + ZIP + Shader Info"
    bl_options = {'REGISTER', 'UNDO'}

    export_path: StringProperty(name="Exportpfad", subtype='DIR_PATH', default="//LazarusExports")
    embed_textures: BoolProperty(name="Texturen einbetten (FBX)", default=False)
    export_shader_info: BoolProperty(name="Shader Info exportieren", default=True)
    export_textures: BoolProperty(name="Texturen extrahieren", default=True)
    only_export_fbx: BoolProperty(name="Nur FBX exportieren", default=False)

    def execute(self, context):
        export_dir = bpy.path.abspath(self.export_path)
        os.makedirs(export_dir, exist_ok=True)

        original_selection = context.selected_objects.copy()
        original_active = context.view_layer.objects.active

        for obj in original_selection:
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            context.view_layer.objects.active = obj

            obj_name = bpy.path.clean_name(obj.name)
            fbx_path = os.path.join(export_dir, obj_name + ".fbx")
            print(f"[Lazarus Export] Exportiere: {obj.name} → {fbx_path}")

            bpy.ops.export_scene.fbx(
                filepath=fbx_path,
                use_selection=True,
                apply_unit_scale=True,
                apply_scale_options='FBX_SCALE_ALL',
                bake_space_transform=True,
                object_types={'MESH', 'ARMATURE'},
                use_mesh_modifiers=True,
                add_leaf_bones=False,
                path_mode='COPY',
                embed_textures=self.embed_textures,
                batch_mode='OFF'
            )

            textures = set()
            shader_info_lines = [f"Object: {obj_name}", "Materials & Shaders:"]
            for slot in obj.material_slots:
                mat = slot.material
                if mat:
                    shader_info_lines.append(f"- Material: {mat.name}")
                    if mat.use_nodes:
                        for node in mat.node_tree.nodes:
                            if node.type == 'TEX_IMAGE' and node.image:
                                tex_path = bpy.path.abspath(node.image.filepath)
                                if os.path.exists(tex_path):
                                    textures.add(tex_path)
                            elif node.type == 'BSDF_PRINCIPLED':
                                shader_info_lines.append(f"  Shader: {node.bl_idname} ({node.label or 'Principled BSDF'})")

            shader_txt_path = os.path.join(export_dir, obj_name + "_shaderinfo.txt")
            if self.export_shader_info:
                with open(shader_txt_path, "w", encoding="utf-8") as f:
                    f.write("\n".join(shader_info_lines))

            if not self.only_export_fbx:
                zip_path = os.path.join(export_dir, obj_name + ".zip")
                with zipfile.ZipFile(zip_path, 'w') as zipf:
                    if os.path.exists(fbx_path):
                        zipf.write(fbx_path, os.path.basename(fbx_path))
                    if self.export_shader_info and os.path.exists(shader_txt_path):
                        zipf.write(shader_txt_path, os.path.basename(shader_txt_path))
                        os.remove(shader_txt_path)
                    if self.export_textures:
                        for tex in textures:
                            dest_tex = os.path.join(export_dir, os.path.basename(tex))
                            shutil.copy(tex, dest_tex)
                            zipf.write(dest_tex, os.path.basename(dest_tex))
                            os.remove(dest_tex)

        bpy.ops.object.select_all(action='DESELECT')
        for obj in original_selection:
            obj.select_set(True)
        context.view_layer.objects.active = original_active

        self.report({'INFO'}, f"Export abgeschlossen für {len(original_selection)} Objekt(e).")
        return {'FINISHED'}


class LAZARUS_PT_export_panel(Panel):
    bl_label = "Lazarus Export Tools"
    bl_idname = "VIEW3D_PT_lazarus_multi_zip_shader"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Lazarus'

    def draw(self, context):
        layout = self.layout
        layout.operator("export_scene.lazarus_multi_zip_shader", text="📦 Export FBX + ZIP + Shader Info")


def register():
    bpy.utils.register_class(LAZARUS_OT_export_each_as_zip)
    bpy.utils.register_class(LAZARUS_PT_export_panel)


def unregister():
    bpy.utils.unregister_class(LAZARUS_OT_export_each_as_zip)
    bpy.utils.unregister_class(LAZARUS_PT_export_panel)


if __name__ == "__main__":
    register()