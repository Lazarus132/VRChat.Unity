using UnityEngine;

/// <summary>
/// Dummy-Klasse, um den Pfad des Addon-Ordners über AssetDatabase zuverlässig zu bestimmen.
/// </summary>
public class BlenderPluginDummy : ScriptableObject { }
