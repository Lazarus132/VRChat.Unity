using UnityEngine;
using UnityEditor;
using System.Diagnostics;
using System.IO;
using System.Linq;

[InitializeOnLoad]
public class BlenderPluginAutoInstaller
{
    private const string PrefKey = "Lazarus_BlenderPluginInstalled";

    static BlenderPluginAutoInstaller()
    {
        if (!EditorPrefs.GetBool(PrefKey, false))
        {
            EditorApplication.delayCall += TryPromptInstall;
        }
    }

    private static void TryPromptInstall()
    {
        string blenderPath = FindBlenderPath();
        if (!string.IsNullOrEmpty(blenderPath))
        {
            bool confirm = EditorUtility.DisplayDialog(
                "🔧 Lazarus Blender Plugin installieren?",
                "Blender wurde gefunden.\nMöchtest du das Lazarus-Plugin automatisch installieren?",
                "Ja, installieren",
                "Nein");

            if (confirm)
            {
                InstallBlenderAddon(blenderPath);
                EditorPrefs.SetBool(PrefKey, true);
                EditorUtility.DisplayDialog("✅ Erfolgreich", "Plugin wurde installiert.", "OK");
            }
        }
    }

    private static string FindBlenderPath()
    {
        string[] paths = System.Environment.GetEnvironmentVariable("PATH").Split(';');
        foreach (string path in paths)
        {
            string exePath = Path.Combine(path.Trim(), "blender.exe");
            if (File.Exists(exePath))
                return exePath;
        }
        return null;
    }

    private static void InstallBlenderAddon(string blenderExe)
    {
        string blenderConfig = Path.Combine(
            System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData),
            "Blender Foundation", "Blender");

        if (!Directory.Exists(blenderConfig))
        {
            UnityEngine.Debug.LogWarning("[Lazarus] Kein Blender-Konfigurationsordner gefunden.");
            return;
        }

        string versionFolder = Directory.GetDirectories(blenderConfig)
            .OrderByDescending(v => v)
            .FirstOrDefault();

        if (string.IsNullOrEmpty(versionFolder)) return;

        string addonTarget = Path.Combine(versionFolder, "scripts", "addons", "LazarusShaderExporter.py");
        string addonSource = Path.Combine(Application.dataPath, "Editor", "Blender", "LazarusShaderExporter.py");

        if (!File.Exists(addonSource))
        {
            UnityEngine.Debug.LogError("[Lazarus] Addon-Quelldatei fehlt!");
            return;
        }

        Directory.CreateDirectory(Path.GetDirectoryName(addonTarget));
        File.Copy(addonSource, addonTarget, true);

        UnityEngine.Debug.Log("[Lazarus] Blender-Addon wurde nach:\n" + addonTarget + " installiert.");
    }
}
