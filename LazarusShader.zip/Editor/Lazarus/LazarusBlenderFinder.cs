using System.Diagnostics;
using System.IO;
using System.Linq;

public static class BlenderFinder
{
    public static string GetBlenderExecutable()
    {
#if UNITY_EDITOR_WIN
        var possiblePaths = new[]
        {
            @"C:\Program Files\Blender Foundation\Blender",
            @"C:\Program Files (x86)\Blender Foundation\Blender"
        };

        foreach (var basePath in possiblePaths)
        {
            if (Directory.Exists(basePath))
            {
                var blenderExe = Directory.GetFiles(basePath, "blender.exe", SearchOption.AllDirectories).FirstOrDefault();
                if (!string.IsNullOrEmpty(blenderExe))
                    return blenderExe;
            }
        }

#elif UNITY_EDITOR_OSX
        var path = "/Applications/Blender.app/Contents/MacOS/Blender";
        if (File.Exists(path)) return path;

#elif UNITY_EDITOR_LINUX
        var path = "/usr/bin/blender";
        if (File.Exists(path)) return path;
#endif
        return null;
    }
}
