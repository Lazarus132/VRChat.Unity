using UnityEngine;
using UnityEditor;
using System.Collections.Generic;

public class LazarusMaterialTool : EditorWindow
{
    private int tab = 0;
    private List<Material> problematicMaterials = new();
    private Vector2 scroll;

    [MenuItem("Lazarus/Material Tool")]
    public static void ShowWindow() => GetWindow<LazarusMaterialTool>("Lazarus Material Tool");

    void OnGUI()
    {
        tab = GUILayout.Toolbar(tab, new[] { "🔍 Checker", "🛠 Fixer" });

        GUILayout.Space(10);
        if (tab == 0) DrawCheckerTab();
        else DrawFixerTab();
    }

    void DrawCheckerTab()
    {
        GUILayout.Label("🔍 Lazarus Material Checker", EditorStyles.boldLabel);

        if (GUILayout.Button("🚦 Alle Materialien prüfen"))
        {
            CheckAllMaterials();
        }

        GUILayout.Space(5);
        GUILayout.Label($"Gefundene problematische Materialien: {problematicMaterials.Count}");

        if (problematicMaterials.Count > 0)
        {
            scroll = GUILayout.BeginScrollView(scroll, GUILayout.Height(200));
            foreach (var mat in problematicMaterials)
                GUILayout.Label("⚠ " + mat.name);
            GUILayout.EndScrollView();
        }
    }

    void DrawFixerTab()
    {
        GUILayout.Label("🛠 Lazarus Material Fixer", EditorStyles.boldLabel);

        if (problematicMaterials.Count == 0)
        {
            EditorGUILayout.HelpBox("⚠️ Erst prüfen, bevor repariert werden kann!", MessageType.Warning);
            return;
        }

        if (GUILayout.Button("🔧 Problematische Materialien automatisch reparieren"))
        {
            FixMaterials();
            problematicMaterials.Clear();
        }
    }

    void CheckAllMaterials()
    {
        problematicMaterials.Clear();
        string[] guids = AssetDatabase.FindAssets("t:Material");

        foreach (string guid in guids)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            Material mat = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (mat == null || mat.shader == null) continue;

            bool hasIssue = false;

            if (mat.HasProperty("_MainTex") && mat.GetTexture("_MainTex") == null)
            {
                if (mat.HasProperty("_Color") && mat.GetColor("_Color").maxColorComponent < 0.05f)
                {
                    Debug.LogWarning($"[Albedo] Farbe fast schwarz ohne Textur: {mat.name}", mat);
                    hasIssue = true;
                }
            }

            if (mat.HasProperty("_UseMetallicTex") && mat.GetFloat("_UseMetallicTex") > 0.5f)
            {
                if (mat.HasProperty("_MetallicTex") && mat.GetTexture("_MetallicTex") == null)
                {
                    Debug.LogWarning($"[Metallic] Map aktiviert, aber leer: {mat.name}", mat);
                    hasIssue = true;
                }
            }

            if (mat.HasProperty("_MetallicTex") && mat.GetTexture("_MetallicTex") != null)
            {
                if (mat.HasProperty("_Metallic") && mat.GetFloat("_Metallic") < 0.05f)
                {
                    Debug.LogWarning($"[Metallic] Map vorhanden, aber Metallic-Wert = 0: {mat.name}", mat);
                    hasIssue = true;
                }
            }

            if (mat.HasProperty("_TexColorTint"))
            {
                Color tint = mat.GetColor("_TexColorTint");
                if (tint.maxColorComponent < 0.1f)
                {
                    Debug.LogWarning($"[Tint] Sehr dunkle Tönung: {mat.name}", mat);
                    hasIssue = true;
                }
            }

            if (hasIssue)
                problematicMaterials.Add(mat);
        }

        Debug.Log($"[Lazarus] Prüfung abgeschlossen. Probleme: {problematicMaterials.Count}");
    }

    void FixMaterials()
    {
        int fixedCount = 0;

        foreach (var mat in problematicMaterials)
        {
            Undo.RecordObject(mat, "Lazarus Auto Fix");

            if (mat.HasProperty("_Color") && mat.GetColor("_Color").maxColorComponent < 0.05f)
            {
                mat.SetColor("_Color", Color.gray);
                Debug.Log($"[Fix] _Color → Grau gesetzt: {mat.name}");
            }

            if (mat.HasProperty("_UseMetallicTex") && mat.GetFloat("_UseMetallicTex") > 0.5f)
            {
                if (mat.HasProperty("_MetallicTex") && mat.GetTexture("_MetallicTex") == null)
                {
                    mat.SetFloat("_UseMetallicTex", 0);
                    Debug.Log($"[Fix] _UseMetallicTex deaktiviert: {mat.name}");
                }
            }

            if (mat.HasProperty("_MetallicTex") && mat.GetTexture("_MetallicTex") != null)
            {
                if (mat.HasProperty("_Metallic") && mat.GetFloat("_Metallic") < 0.05f)
                {
                    mat.SetFloat("_Metallic", 0.2f);
                    Debug.Log($"[Fix] _Metallic → 0.2 gesetzt: {mat.name}");
                }
            }

            if (mat.HasProperty("_TexColorTint") && mat.GetColor("_TexColorTint").maxColorComponent < 0.1f)
            {
                mat.SetColor("_TexColorTint", new Color(0.8f, 0.8f, 0.8f, 1));
                Debug.Log($"[Fix] _TexColorTint → Hellgrau gesetzt: {mat.name}");
            }

            EditorUtility.SetDirty(mat);
            fixedCount++;
        }

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log($"[LazarusFixer] {fixedCount} Materialien automatisch korrigiert.");
    }
}
