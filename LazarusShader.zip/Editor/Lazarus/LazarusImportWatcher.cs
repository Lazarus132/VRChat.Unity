
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Experimental.SceneManagement;
using UnityEngine.SceneManagement;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Collections.Generic;

[InitializeOnLoad]
public static class LazarusImportWatcher
{
    private const string EnabledKey = "Lazarus_ImportWatcherEnabled";
    private const string FolderKey = "Lazarus_ImportFolder";
    private const string PrefabKey = "Lazarus_CreatePrefabs";
    private const string PrefabFolderKey = "Lazarus_PrefabFolder";

    static LazarusImportWatcher()
    {
        if (IsEnabled())
        {
            EditorApplication.update += Check;
        }
    }

    public static bool IsEnabled() => EditorPrefs.GetBool(EnabledKey, false);
    public static void SetEnabled(bool enabled)
    {
        EditorPrefs.SetBool(EnabledKey, enabled);
        if (enabled)
            EditorApplication.update += Check;
        else
            EditorApplication.update -= Check;
    }

    public static string GetImportFolder() =>
        EditorPrefs.GetString(FolderKey, Path.Combine(Application.dataPath, "../Lazarus_Import"));

    public static void SetImportFolder(string folder) =>
        EditorPrefs.SetString(FolderKey, folder);

    public static bool PrefabCreationEnabled() => EditorPrefs.GetBool(PrefabKey, false);
    public static void SetPrefabCreation(bool enabled) => EditorPrefs.SetBool(PrefabKey, enabled);

    public static string GetPrefabFolder() =>
        EditorPrefs.GetString(PrefabFolderKey, "Assets/LazarusPrefabs");

    public static void SetPrefabFolder(string folder) =>
        EditorPrefs.SetString(PrefabFolderKey, folder);

    private static void Check()
    {
        string folder = GetImportFolder();
        if (!Directory.Exists(folder)) return;

        var zips = Directory.GetFiles(folder, "*.zip");
        foreach (string zip in zips)
        {
            try
            {
                ImportZip(zip);
                File.Delete(zip);
            }
            catch (System.Exception ex)
            {
                Debug.LogError("[Lazarus] Fehler beim Importieren von ZIP:" + ex);
            }
        }
    }

    private static void ImportZip(string zipPath)
    {
        Debug.Log("[Lazarus] Importiere ZIP: " + zipPath);
        string extractFolder = Path.Combine(Path.GetTempPath(), "LazarusExtract");

        if (Directory.Exists(extractFolder)) Directory.Delete(extractFolder, true);
        ZipFile.ExtractToDirectory(zipPath, extractFolder);

        string[] importExtensions = new[] { ".fbx", ".png", ".jpg", ".jpeg", ".tga" };
        List<string> copiedFiles = new();

        foreach (string file in Directory.GetFiles(extractFolder, "*.*", SearchOption.AllDirectories))
        {
            string ext = Path.GetExtension(file).ToLower();
            if (!importExtensions.Contains(ext)) continue;

            string destPath = Path.Combine(Application.dataPath, Path.GetFileName(file));
            File.Copy(file, destPath, true);
            copiedFiles.Add("Assets/" + Path.GetFileName(file));
        }

        AssetDatabase.Refresh();

        Shader lazarusShader = Shader.Find("VRChat/LazarusShader");
        if (lazarusShader == null)
        {
            Debug.LogError("[Lazarus] Shader 'VRChat/LazarusShader' wurde NICHT gefunden!");
            return;
        }

        foreach (string assetPath in copiedFiles.Where(f => f.EndsWith(".fbx")))
        {
            GameObject fbx = AssetDatabase.LoadAssetAtPath<GameObject>(assetPath);
            if (fbx == null)
            {
                Debug.LogWarning("[Lazarus] Konnte FBX nicht laden: " + assetPath);
                continue;
            }

            GameObject instance = GameObject.Instantiate(fbx);
            instance.name = fbx.name + "_Imported";

            LazarusMaterialUtility.AssignAndDuplicateMaterials(instance);

            if (PrefabCreationEnabled())
            {
                string prefabFolder = GetPrefabFolder();
                if (!Directory.Exists(prefabFolder))
                    Directory.CreateDirectory(prefabFolder);

                string prefabPath = Path.Combine(prefabFolder, instance.name + ".prefab").Replace("\\", "/");
                prefabPath = AssetDatabase.GenerateUniqueAssetPath(prefabPath);
                PrefabUtility.SaveAsPrefabAsset(instance, prefabPath);
            }
        }

        Debug.Log("[Lazarus] Import abgeschlossen.");
    }
}
