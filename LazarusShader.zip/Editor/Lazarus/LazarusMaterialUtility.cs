using UnityEngine;
using UnityEditor;
using System.Linq;
using System.IO;

public static class LazarusMaterialUtility
{
    private const string DefaultMaterialPath = "Assets/_Lazarus.mat";
    private const string LazarusShaderName = "VRChat/LazarusShader";

    public static void AssignAndDuplicateMaterials(GameObject instance)
    {
        if (instance == null)
        {
            Debug.LogError("[Lazarus] Instance ist null – Materialzuweisung abgebrochen.");
            return;
        }

        Shader lazarusShader = Shader.Find(LazarusShaderName);
        if (lazarusShader == null)
        {
            Debug.LogError($"[Lazarus] Shader '{LazarusShaderName}' nicht gefunden.");
            return;
        }

        Material baseMaterial = AssetDatabase.LoadAssetAtPath<Material>(DefaultMaterialPath);
        if (baseMaterial == null)
        {
            Debug.LogError($"[Lazarus] Material '{DefaultMaterialPath}' nicht gefunden.");
            return;
        }

        var renderers = instance.GetComponentsInChildren<Renderer>(true);
        if (renderers.Length == 0)
        {
            Debug.LogWarning($"[Lazarus] Keine Renderer in '{instance.name}' gefunden.");
            return;
        }

        foreach (Renderer renderer in renderers)
        {
            if (renderer.sharedMaterials == null || renderer.sharedMaterials.Length == 0)
                continue;

            Material[] newMaterials = renderer.sharedMaterials.Select((origMat, i) =>
            {
                string materialName = $"{instance.name}_{renderer.gameObject.name}_Mat{i}.mat";
                string folderPath = "Assets/LazarusGeneratedMaterials";

                if (!AssetDatabase.IsValidFolder(folderPath))
                    AssetDatabase.CreateFolder("Assets", "LazarusGeneratedMaterials");

                string fullPath = Path.Combine(folderPath, materialName).Replace("\\", "/");
                fullPath = AssetDatabase.GenerateUniqueAssetPath(fullPath);

                Material newMat = new Material(baseMaterial)
                {
                    shader = lazarusShader,
                    name = Path.GetFileNameWithoutExtension(materialName)
                };

                AssetDatabase.CreateAsset(newMat, fullPath);
                return newMat;
            }).ToArray();

            renderer.sharedMaterials = newMaterials;
        }

        AssetDatabase.SaveAssets();
        Debug.Log($"[Lazarus] Materialien für '{instance.name}' erfolgreich dupliziert und zugewiesen.");
    }
}
