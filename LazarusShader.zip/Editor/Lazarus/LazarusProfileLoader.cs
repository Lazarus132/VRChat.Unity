using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public static class LazarusProfileLoader
{
    private const string ProfilePathKey = "Lazarus_ActiveProfilePath";

    public static LazarusImportProfile GetActiveProfile()
    {
        string path = EditorPrefs.GetString(ProfilePathKey, "");
        if (!string.IsNullOrEmpty(path))
            return AssetDatabase.LoadAssetAtPath<LazarusImportProfile>(path);
        return null;
    }

    public static void SetActiveProfile(LazarusImportProfile profile)
    {
        if (profile == null)
            EditorPrefs.DeleteKey(ProfilePathKey);
        else
            EditorPrefs.SetString(ProfilePathKey, AssetDatabase.GetAssetPath(profile));
    }

    public static List<LazarusImportProfile> GetAllProfiles()
    {
        return AssetDatabase.FindAssets("t:LazarusImportProfile")
            .Select(guid => AssetDatabase.GUIDToAssetPath(guid))
            .Select(path => AssetDatabase.LoadAssetAtPath<LazarusImportProfile>(path))
            .Where(profile => profile != null)
            .ToList();
    }
}
