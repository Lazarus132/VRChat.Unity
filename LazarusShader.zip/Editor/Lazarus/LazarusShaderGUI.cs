using UnityEngine;
using UnityEditor;
using System.Linq;

public class LazarusShaderGUI : ShaderGUI
{
    private MaterialEditor _editor;
    private static MaterialProperty[] _properties;
    private int tabIndex = 0;
    private GUIContent[] tabs;

    private MaterialProperty Find(string name) => FindProperty(name, _properties);

    public override void OnGUI(MaterialEditor materialEditor, MaterialProperty[] properties)
    {
        _editor = materialEditor;
        _properties = properties;

        Material material = materialEditor.target as Material;

        DrawRenderModePopup(material);

        InitTabs();

        GUILayout.Space(5);
        tabIndex = GUILayout.Toolbar(tabIndex, tabs, GUILayout.Height(32));
        GUILayout.Space(10);

        switch (tabIndex)
        {
            case 0: DrawMainTab(); break;
            case 1: DrawPBRTab(); break;
            case 2: DrawEmissionTab(); break;
            case 3: DrawWheelTab(); break;
            case 4: DrawReflectionTab(); break;
            case 5: DrawOtherTab(); break;
        }
    }

    private void InitTabs()
    {
        if (tabs != null) return;
        tabs = new GUIContent[]
        {
            LoadIconTab("tab_albedo", "Albedo & Normal"),
            LoadIconTab("tab_pbr", "PBR"),
            LoadIconTab("tab_emission", "Emission"),
            LoadIconTab("tab_wheel", "Rad"),
            LoadIconTab("tab_reflection", "Reflexion"),
            LoadIconTab("tab_misc", "Sonstiges")
        };
    }

    private GUIContent LoadIconTab(string spriteName, string tooltip)
    {
        string path = "Assets/Editor/Lazarus/Icons/LazarusTabsheet.png";
        Sprite[] sprites = AssetDatabase.LoadAllAssetRepresentationsAtPath(path)
            .OfType<Sprite>().ToArray();

        Sprite sprite = System.Array.Find(sprites, s => s.name == spriteName);
        if (sprite == null)
        {
            Debug.LogWarning($"Sprite '{spriteName}' nicht gefunden im Sheet: {path}");
            return new GUIContent(tooltip);
        }

        // Extrahiere Sprite in neues Texture2D
        Texture2D extracted = new Texture2D((int)sprite.rect.width, (int)sprite.rect.height);
        Color[] pixels = sprite.texture.GetPixels(
            (int)sprite.rect.x,
            (int)sprite.rect.y,
            (int)sprite.rect.width,
            (int)sprite.rect.height
        );
        extracted.SetPixels(pixels);
        extracted.Apply();

        return new GUIContent(extracted, tooltip);
    }



    private bool DrawToggle(string label, MaterialProperty prop)
    {
        EditorGUI.BeginChangeCheck();
        bool value = EditorGUILayout.Toggle(label, prop.floatValue > 0.5f);
        if (EditorGUI.EndChangeCheck())
            prop.floatValue = value ? 1f : 0f;
        return value;
    }

    private void DrawMainTab()
    {
        GUILayout.Label("Albedo", EditorStyles.boldLabel);
        if (DrawToggle("Textur verwenden", Find("_UseAlbedoTex")))
            _editor.TexturePropertySingleLine(new GUIContent("Albedo Textur"), Find("_MainTex"));
        _editor.ColorProperty(Find("_Color"), "Albedo-Farbe");

        GUILayout.Space(5);
        GUILayout.Label("Normalen", EditorStyles.boldLabel);
        if (DrawToggle("Normalenkarte verwenden", Find("_UseNormalTex")))
            _editor.TexturePropertySingleLine(new GUIContent("Normalenkarte"), Find("_NormalTex"));

        GUILayout.Space(5);
        GUILayout.Label("Höhenkarte", EditorStyles.boldLabel);
        if (DrawToggle("Höhenkarte verwenden", Find("_UseHeightMap")))
            _editor.TexturePropertySingleLine(new GUIContent("Höhenkarte"), Find("_HeightMap"));
        _editor.ShaderProperty(Find("_HeightScale"), "Höhen-Skalierung");
    }

    private void DrawPBRTab()
    {
        GUILayout.Label("PBR", EditorStyles.boldLabel);

        if (DrawToggle("Metallisch-Textur verwenden", Find("_UseMetallicTex")))
            _editor.TexturePropertySingleLine(new GUIContent("Metallisch"), Find("_MetallicTex"));
        _editor.ShaderProperty(Find("_Metallic"), "Metallisch");

        if (DrawToggle("Rauheits-Textur verwenden", Find("_UseRoughnessTex")))
            _editor.TexturePropertySingleLine(new GUIContent("Rauheit"), Find("_RoughnessTex"));
        _editor.ShaderProperty(Find("_Roughness"), "Rauheit");

        if (DrawToggle("AO-Textur verwenden", Find("_UseAOTex")))
            _editor.TexturePropertySingleLine(new GUIContent("AO-Textur"), Find("_AOTex"));

        if (DrawToggle("ID-Maske verwenden", Find("_UseIDTex")))
            _editor.TexturePropertySingleLine(new GUIContent("ID-Maske"), Find("_IDTex"));
    }

    private void DrawEmissionTab()
    {
        GUILayout.Label("Emission", EditorStyles.boldLabel);
        if (DrawToggle("Emission aktivieren", Find("_EmissionToggle")))
        {
            MaterialProperty mode = Find("_WheelEmissionMode");
            string[] wheelEmissionOptions = { "Aus", "Nur Rad", "Beides" };
            mode.floatValue = EditorGUILayout.Popup("Rad-Emission", (int)mode.floatValue, wheelEmissionOptions);
            if (DrawToggle("Emissions-Textur verwenden", Find("_UseEmissionTex")))
                _editor.TexturePropertySingleLine(new GUIContent("Emissions-Textur"), Find("_EmissionTex"));

            _editor.ColorProperty(Find("_EmissionColor"), "Farbe");
            _editor.ShaderProperty(Find("_EmissionStrength"), "Stärke");
        }
    }

    private void DrawWheelCenterInteractive(MaterialProperty centerProp)
    {
        GUILayout.Label("Rad-Zentrum (UV)", EditorStyles.boldLabel);
        Rect r = GUILayoutUtility.GetRect(128, 128, GUILayout.ExpandWidth(false));

        // Hintergrund & Gitter
        EditorGUI.DrawRect(r, new Color(0.12f, 0.12f, 0.12f));
        Handles.color = new Color(0.3f, 0.3f, 0.3f);
        for (int i = 1; i < 4; i++)
        {
            float offset = r.width * i / 4f;
            Handles.DrawLine(new Vector2(r.x + offset, r.y), new Vector2(r.x + offset, r.yMax));
            Handles.DrawLine(new Vector2(r.x, r.y + offset), new Vector2(r.xMax, r.y + offset));
        }

        // Aktuelles Zentrum lesen
        Vector4 center = centerProp.vectorValue;
        Vector2 centerPixel = new Vector2(r.x + center.x * r.width, r.y + (1 - center.y) * r.height);

        // Interaktive Drag-Funktion
        Event e = Event.current;
        if (e.type == EventType.MouseDown && r.Contains(e.mousePosition))
        {
            GUI.FocusControl(null);
            e.Use();
        }

        if (e.type == EventType.MouseDrag && r.Contains(e.mousePosition) && e.button == 0)
        {
            Vector2 local = e.mousePosition;
            float x = Mathf.Clamp01((local.x - r.x) / r.width);
            float y = Mathf.Clamp01(1 - ((local.y - r.y) / r.height));

            // Aspect-Korrektur bei aktivierter Option
            Material targetMat = _editor.target as Material;
            bool autoAspect = targetMat.HasProperty("_AutoAspectUV") && targetMat.GetFloat("_AutoAspectUV") > 0.5f;

            if (autoAspect && targetMat.HasProperty("_ImageAspect"))
            {
                float aspect = targetMat.GetFloat("_ImageAspect");
                float scaleY = 1f / aspect;
                y = Mathf.Clamp01(0.5f + ((y - 0.5f) * scaleY));
            }

            center = new Vector4(x, y, 0, 0);
            centerProp.vectorValue = center;
            GUI.changed = true;
            e.Use();
        }

        // Punkt zeichnen
        float size = 8;
        Rect dotRect = new Rect(centerPixel.x - size / 2, centerPixel.y - size / 2, size, size);
        EditorGUI.DrawRect(dotRect, Color.green);

        // Slider
        EditorGUI.indentLevel++;
        float newX = EditorGUILayout.Slider("U (X)", center.x, 0f, 1f);
        float newY = EditorGUILayout.Slider("V (Y)", center.y, 0f, 1f);
        EditorGUI.indentLevel--;
        if (newX != center.x || newY != center.y)
        {
            centerProp.vectorValue = new Vector4(newX, newY, 0, 0);
        }
    }

    private void DrawWheelTab()
    {
        GUILayout.Label("Rad-Modus", EditorStyles.boldLabel);
        MaterialProperty wheelMode = Find("_WheelMode");
        MaterialProperty wheelShape = Find("_WheelShape");
        MaterialProperty wheelCornerRadius = Find("_WheelCornerRadius");
        MaterialProperty wheelRadius = Find("_WheelRadius");
        MaterialProperty centerProp = Find("_WheelCenter"); // ✅ WICHTIG!
        MaterialProperty uvScale = Find("_WheelUVScale");

        string[] options = new[] { "Aus", "Maske", "Overlay", "Beides" };
        wheelMode.floatValue = EditorGUILayout.Popup("Rad-Modus", (int)wheelMode.floatValue, options);

        if (wheelMode.floatValue > 0)
        {
            GUILayout.Space(5);
            GUILayout.Label("Rad-Texturen", EditorStyles.boldLabel);
            DrawToggle("Bild Automatisch Skalieren", Find("_AutoScaleWheelTex"));
            DrawToggle("Radtextur zentrieren & zuschneiden", Find("_AutoCropCenter"));
            MaterialProperty imageAspect = Find("_ImageAspect");
            _editor.FloatProperty(imageAspect, "Bildseitenverhältnis (Breite / Höhe)");
            GUILayout.Space(5);
            GUILayout.Label("Bildseitenverhältnis Vorschau", EditorStyles.boldLabel);

            Rect previewRect = GUILayoutUtility.GetRect(128, 128, GUILayout.ExpandWidth(false));
            EditorGUI.DrawRect(previewRect, new Color(0.1f, 0.1f, 0.1f, 1f)); // Hintergrund

            float aspect = imageAspect.floatValue;
            float maxWidth = previewRect.width;
            float maxHeight = previewRect.height;

            float previewWidth = maxWidth;
            float previewHeight = maxWidth / aspect;

            if (previewHeight > maxHeight)
            {
                previewHeight = maxHeight;
                previewWidth = previewHeight * aspect;
            }

            Rect aspectRect = new Rect(
                previewRect.x + (maxWidth - previewWidth) / 2f,
                previewRect.y + (maxHeight - previewHeight) / 2f,
                previewWidth,
                previewHeight
            );

            // grüner Rahmen
            Handles.color = Color.green;
            Handles.DrawSolidRectangleWithOutline(aspectRect, new Color(0, 1, 0, 0.1f), Color.green);

            EditorGUILayout.HelpBox("Grüner Rahmen zeigt das Bildseitenverhältnis (UV-Form).", MessageType.Info);

            GUILayout.Space(5);
            GUILayout.Label("Rad-Texturen", EditorStyles.boldLabel);
            DrawToggle("HDR-Radfarbe verwenden", Find("_UseHDRWheelColor"));
            _editor.ColorProperty(Find("_WheelColorSDR"), "SDR-Radfarbe");
            _editor.ColorProperty(Find("_WheelColorHDR"), "HDR-Radfarbe");
            _editor.TexturePropertySingleLine(new GUIContent("Rad-Textur SDR"), Find("_WheelTexSDR"));
            _editor.TexturePropertySingleLine(new GUIContent("Rad-Textur HDR"), Find("_WheelTexHDR"));
            DrawToggle("HDR-Rad verwenden", Find("_UseHDRWheel"));
            _editor.ShaderProperty(Find("_WheelBrightness"), "Helligkeit");
            _editor.ShaderProperty(Find("_WheelOverlayStrength"), "Overlay-Stärke");
            _editor.ShaderProperty(uvScale, "Rad Zoomfaktor");
            DrawToggle("Rad invertieren", Find("_InvertWheel"));
            DrawToggle("Außerhalb des Radius begrenzen", Find("_ClampOutside"));

            // Formauswahl
            GUILayout.Space(5);
            GUILayout.Label("Form", EditorStyles.boldLabel);
            string[] shapeOptions = new[] { "Kreis", "Rechteck" };
            int selectedShape = (int)wheelShape.floatValue;
            selectedShape = EditorGUILayout.Popup("Rad-Form", selectedShape, shapeOptions);
            wheelShape.floatValue = selectedShape;

            // Dynamisch Slider ein-/ausblenden
            if (selectedShape == 1)
            {
                // Rechteck ⇒ Eckenradius manuell
                _editor.ShaderProperty(wheelCornerRadius, "Eckenradius");
            }
            else
            {
                // Kreis ⇒ Eckenradius = Radius
                wheelCornerRadius.floatValue = wheelRadius.floatValue;
            }

            GUILayout.Space(5);
            GUILayout.Label("UV-Zentrum", EditorStyles.boldLabel);
            DrawWheelCenterInteractive(Find("_WheelCenter"));

            GUILayout.Space(5);
            GUILayout.Label("Rad-Dynamik", EditorStyles.boldLabel);
            DrawToggle("Rad dreht sich", Find("_WheelRotateToggle"));
            _editor.ShaderProperty(Find("_WheelRotateSpeed"), "Rotationsgeschwindigkeit");

            GUILayout.Space(5);
            GUILayout.Label("AudioLink", EditorStyles.boldLabel);
            var audioToggle = Find("_WheelAudioBandToggle");
            if (DrawToggle("AudioLink verwenden", audioToggle))
            {
                EditorGUI.indentLevel++;
                _editor.ShaderProperty(Find("_WheelAudioBand"), "Band Index");
                DrawToggle("Rotation durch AudioLink", Find("_WheelAudioRotationToggle"));
                DrawToggle("Helligkeit durch AudioLink", Find("_WheelAudioBrightnessToggle"));
                DrawToggle("Textur durch AudioLink", Find("_WheelAudioTextureToggle"));
                EditorGUI.indentLevel--;
            }
            UpdateImageAspect(_editor.target as Material);
        }
    }

    private void UpdateImageAspect(Material mat)
    {
        if (mat == null) return;

        if (!mat.HasProperty("_AutoScaleWheelTex") || mat.GetFloat("_AutoScaleWheelTex") < 0.5f)
            return;

        bool useHDR = mat.HasProperty("_UseHDRWheel") && mat.GetFloat("_UseHDRWheel") > 0.5f;
        Texture tex = useHDR ? mat.GetTexture("_WheelTexHDR") : mat.GetTexture("_WheelTexSDR");

        if (tex != null && tex.height > 0)
        {
            float aspect = (float)tex.width / tex.height;
            mat.SetFloat("_ImageAspect", aspect);
        }
    }

    private void DrawReflectionTab()
    {
        GUILayout.Label("Reflexion", EditorStyles.boldLabel);
        DrawToggle("Reflexion verwenden", Find("_UseReflection"));
        _editor.TexturePropertySingleLine(new GUIContent("Reflexions-Cubemap"), Find("_ReflectionTex"));
        _editor.ShaderProperty(Find("_ReflMipCount"), "Mip-Anzahl");

        if (DrawToggle("Benutzerdefinierte Reflexion verwenden", Find("_UseReflCustom")))
        {
            _editor.TexturePropertySingleLine(new GUIContent("Custom Reflexion"), Find("_ReflCustomTex"));
            _editor.ShaderProperty(Find("_ReflCustomStrength"), "Stärke");
        }
    }

    private void DrawOtherTab()
    {
        GUILayout.Label("Tönung", EditorStyles.boldLabel);
        bool useHDRTint = DrawToggle("HDR-Tönung verwenden", Find("_UseHDRTint"));
        bool useSDRTint = DrawToggle("SDR-Tönung verwenden", Find("_UseSDRTint"));
        if (useSDRTint)
            _editor.ColorProperty(Find("_TintSDR"), "SDR-Farbe");
        if (useHDRTint)
        {
            _editor.ColorProperty(Find("_TintHDR"), "HDR-Farbe");
            _editor.ShaderProperty(Find("_TintHDRStrength"), "HDR-Stärke");
        }

        GUILayout.Space(5);
        GUILayout.Label("Rendering-Modus", EditorStyles.boldLabel);

        Material material = _editor.target as Material;
        int selectedMode = Mathf.RoundToInt(material.GetFloat("_RenderMode"));
        string[] renderingModes = { "Opaque", "Cutout", "Fade", "Transparent" };
        int newMode = EditorGUILayout.Popup("Modus", selectedMode, renderingModes);

        if (newMode != selectedMode)
        {
            material.SetFloat("_RenderMode", newMode);
            SetupMaterialWithRenderingMode(material, newMode);
        }

        GUILayout.Space(5);
        GUILayout.Label("Sonstiges", EditorStyles.boldLabel);
        if (selectedMode == 2 || selectedMode == 3) // Nur für Fade & Transparent
        {
            _editor.ShaderProperty(Find("_CustomTransparency"), "Transparenz (sichtbar)");
        }
        else
        {
            EditorGUILayout.HelpBox("Transparenz wirkt nur im Modus 'Fade' oder 'Transparent'", MessageType.Info);
            _editor.ShaderProperty(Find("_CustomTransparency"), "Transparenz (inaktiv)");
        }
        _editor.ShaderProperty(Find("_IBLStrength"), "IBL-Stärke");
    }
    
    void DrawRenderModePopup(Material material)
    {
        int mode = (int)material.GetFloat("_RenderMode");
        EditorGUI.BeginChangeCheck();
        mode = EditorGUILayout.Popup("Rendering Mode", mode, new[] { "Opaque", "Cutout", "Fade", "Transparent" });
        if (EditorGUI.EndChangeCheck())
        {
            foreach (var obj in _editor.targets)
                SetupMaterialWithRenderingMode((Material)obj, mode);
        }
    }

    static void SetupMaterialWithRenderingMode(Material material, int mode)
    {
        material.SetFloat("_RenderMode", mode);
        switch (mode)
        {
            case 0: // Opaque
                material.SetOverrideTag("RenderType", "Opaque");
                material.renderQueue = -1;
                material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.One);
                material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.Zero);
                material.SetInt("_ZWrite", 1);
                material.DisableKeyword("_RENDERING_CUTOUT");
                material.DisableKeyword("_RENDERING_FADE");
                material.DisableKeyword("_RENDERING_TRANSPARENT");
                material.EnableKeyword("_RENDERING_OPAQUE");
                break;
            case 1: // Cutout
                material.SetOverrideTag("RenderType", "Cutout");
                material.renderQueue = (int)UnityEngine.Rendering.RenderQueue.AlphaTest;
                material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.One);
                material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.Zero);
                material.SetInt("_ZWrite", 1);
                material.EnableKeyword("_RENDERING_CUTOUT");
                material.DisableKeyword("_RENDERING_FADE");
                material.DisableKeyword("_RENDERING_TRANSPARENT");
                material.DisableKeyword("_RENDERING_OPAQUE");
                break;
            case 2: // Fade
                material.SetOverrideTag("RenderType", "Transparent");
                material.renderQueue = (int)UnityEngine.Rendering.RenderQueue.Transparent;
                material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
                material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
                material.SetInt("_ZWrite", 0);
                material.DisableKeyword("_RENDERING_CUTOUT");
                material.EnableKeyword("_RENDERING_FADE");
                material.DisableKeyword("_RENDERING_TRANSPARENT");
                material.DisableKeyword("_RENDERING_OPAQUE");
                break;
            case 3: // Transparent
                material.SetOverrideTag("RenderType", "Transparent");
                material.renderQueue = (int)UnityEngine.Rendering.RenderQueue.Transparent;
                material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
                material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
                material.SetInt("_ZWrite", 0);
                material.DisableKeyword("_RENDERING_CUTOUT");
                material.DisableKeyword("_RENDERING_FADE");
                material.EnableKeyword("_RENDERING_TRANSPARENT");
                material.DisableKeyword("_RENDERING_OPAQUE");
                break;
        }
    }

    void DrawDefaultShaderProperties()
    {
        foreach (var prop in _properties)
        {
            if (prop.flags.HasFlag(MaterialProperty.PropFlags.HideInInspector)) continue;
            _editor.ShaderProperty(prop, prop.displayName);
        }
    }


}
