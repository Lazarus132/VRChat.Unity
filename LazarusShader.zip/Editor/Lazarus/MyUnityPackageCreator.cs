using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;

public class UnityPackageExporter : EditorWindow
{
    private string exportFileName = "LazarusShader_FilteredExport.unitypackage";
    private string keyword = "Lazarus";

    [MenuItem("Lazarus/Export Lazarus Shader Package")]
    public static void ShowWindow()
    {
        GetWindow<UnityPackageExporter>("Lazarus Exporter");
    }

    void OnGUI()
    {
        GUILayout.Label("Lazarus Shader Export", EditorStyles.boldLabel);
        exportFileName = EditorGUILayout.TextField("Dateiname", exportFileName);
        keyword = EditorGUILayout.TextField("Suchbegriff (z. B. Lazarus)", keyword);

        if (GUILayout.Button("Exportiere UnityPackage"))
        {
            ExportFilteredAssets();
        }
    }

    void ExportFilteredAssets()
    {
        List<string> filesToExport = new List<string>();

        // Shader-Dateien mit Filter (z. B. Lazarus)
        string[] shaderGUIDs = AssetDatabase.FindAssets("t:Shader", new[] { "Assets" });
        foreach (string guid in shaderGUIDs)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            if (path.Contains(keyword) && path.EndsWith(".shader"))
                filesToExport.Add(path);
        }

        // Material-Dateien mit Filter (z. B. Lazarus)
        string[] matGUIDs = AssetDatabase.FindAssets("t:Material", new[] { "Assets" });
        foreach (string guid in matGUIDs)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            if (path.Contains(keyword) && path.EndsWith(".mat"))
                filesToExport.Add(path);
        }

        // Alle Editor-Skripte
        if (Directory.Exists("Assets/Editor"))
        {
            string[] editorScripts = Directory.GetFiles("Assets/Editor", "*.cs", SearchOption.AllDirectories);
            foreach (string fullPath in editorScripts)
            {
                string path = fullPath.Replace("\\", "/");
                filesToExport.Add(path);
            }
        }

        if (filesToExport.Count == 0)
        {
            Debug.LogWarning("⚠️ Keine passenden Dateien gefunden.");
            return;
        }

        string exportPath = Path.Combine("Assets", exportFileName);
        AssetDatabase.ExportPackage(filesToExport.ToArray(), exportPath, ExportPackageOptions.Interactive);
        Debug.Log($"✅ UnityPackage erstellt: {exportPath}");
    }
}
