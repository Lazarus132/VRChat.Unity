using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(MaterialEditor), true)]
public class LazarusShaderWheelHandle : MaterialEditor
{
    private static readonly string ShaderName = "VRChat/LazarusShader";
    private static readonly string CenterProp = "_WheelCenter";
    private static readonly string ToggleProp = "_ShowCenterHandle";

    void OnSceneGUI()
    {
        if (target is not Material material)
            return;

        // Prüfen, ob Shader stimmt
        if (material.shader.name != ShaderName)
            return;

        // Toggle abfragen
        if (!material.HasProperty(ToggleProp) || material.GetFloat(ToggleProp) < 0.5f)
            return;

        // Position im UV-Raum
        if (!material.HasProperty(CenterProp)) return;
        Vector4 uvCenter = material.GetVector(CenterProp);

        // Weltposition schätzen: Hier brauchst du ggf. Zugriff auf das Mesh
        Transform t = Selection.activeTransform;
        if (t == null) return;

        Vector3 worldPos = t.position + new Vector3(
            (uvCenter.x - 0.5f) * 2f,
            (uvCenter.y - 0.5f) * 2f,
            0f
        );

        // Handle anzeigen
        EditorGUI.BeginChangeCheck();
        Vector3 newWorldPos = Handles.PositionHandle(worldPos, Quaternion.identity);
        if (EditorGUI.EndChangeCheck())
        {
            // Neue Werte berechnen (zurück zu UV)
            Vector3 localOffset = newWorldPos - t.position;
            float newU = 0.5f + localOffset.x * 0.5f;
            float newV = 0.5f + localOffset.y * 0.5f;

            material.SetVector(CenterProp, new Vector4(newU, newV, 0, 0));
        }
    }
}
