// Assets/Editor/Lazarus/LazarusManager.cs
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

public class LazarusManager : EditorWindow
{
    private int selectedProfileIndex = -1;
    private List<LazarusImportProfile> availableProfiles;
    private LazarusImportProfile activeProfile;

    private List<GameObject> targets = new();
    private Shader lazarusShader;
    private const string kShaderName = "VRChat/LazarusShader";

    [MenuItem("Lazarus/Tool")]
    public static void Open() => GetWindow<LazarusManager>("Lazarus Tool");

    [MenuItem("Lazarus/Shader duplizieren & anwenden %#&l")]
    public static void ApplyShaderToSelection()
    {
        var manager = GetWindow<LazarusManager>();
        manager.targets = Selection.gameObjects.ToList();
        manager.AssignAndDuplicateMaterials();
    }

    [MenuItem("Lazarus/Zielobjekte leeren %#&c")]
    public static void ClearTargets()
    {
        var manager = GetWindow<LazarusManager>();
        manager.targets.Clear();
        Debug.Log("[Lazarus] Zielobjekte wurden geleert.");
    }

    private void OnEnable()
    {
        availableProfiles = LazarusProfileLoader.GetAllProfiles();
        activeProfile = LazarusProfileLoader.GetActiveProfile();
        selectedProfileIndex = availableProfiles.IndexOf(activeProfile);
        lazarusShader = activeProfile != null ? activeProfile.targetShader : Shader.Find(kShaderName);
    }

    void OnGUI()
    {
        DrawProfileDropdown();
        GUILayout.Space(10);
        GUILayout.Label("Lazarus Shader Tool", EditorStyles.boldLabel);
        DrawImportSettings();
        GUILayout.Space(10);
        HandleDragAndDrop();

        if (GUILayout.Button("✨ Shader anwenden & duplizieren")) AssignAndDuplicateMaterials();

        GUILayout.Space(10);
        DrawPreview();
    }

    void DrawProfileDropdown()
    {
        GUILayout.Label("📄 Aktives Import-Profil", EditorStyles.boldLabel);

        availableProfiles = LazarusProfileLoader.GetAllProfiles();
        if (availableProfiles.Count == 0)
        {
            EditorGUILayout.HelpBox("⚠️ Keine Profile gefunden.\nErstelle eines mit Rechtsklick im Projektfenster → Create → Lazarus → Import Profile.", MessageType.Warning);
            return;
        }

        string[] names = availableProfiles.Select(p => p.profileName).ToArray();
        int newIndex = EditorGUILayout.Popup("Profil", selectedProfileIndex, names);

        if (newIndex != selectedProfileIndex && newIndex >= 0)
        {
            selectedProfileIndex = newIndex;
            activeProfile = availableProfiles[newIndex];
            LazarusProfileLoader.SetActiveProfile(activeProfile);
            lazarusShader = activeProfile.targetShader;
            Debug.Log($"[Lazarus] Profil aktiviert: {activeProfile.profileName}");
        }
    }


    void DrawImportSettings()
    {
        GUILayout.Label("🔁 Live-Import Einstellungen", EditorStyles.boldLabel);
        bool enabled = LazarusImportWatcher.IsEnabled();
        bool newEnabled = EditorGUILayout.Toggle("Live-Import aktiv", enabled);
        if (enabled != newEnabled) LazarusImportWatcher.SetEnabled(newEnabled);

        string path = LazarusImportWatcher.GetImportFolder();
        string newPath = EditorGUILayout.TextField("Import-Ordner", path);
        if (newPath != path) LazarusImportWatcher.SetImportFolder(newPath);

        if (GUILayout.Button("📂 Ordner öffnen")) EditorUtility.RevealInFinder(newPath);

        GUILayout.Space(5);
        bool prefabToggle = LazarusImportWatcher.PrefabCreationEnabled();
        bool newToggle = EditorGUILayout.Toggle("Automatisch Prefabs erstellen", prefabToggle);
        if (newToggle != prefabToggle) LazarusImportWatcher.SetPrefabCreation(newToggle);

        string prefabFolder = LazarusImportWatcher.GetPrefabFolder();
        string newFolder = EditorGUILayout.TextField("Prefab-Zielordner", prefabFolder);
        if (newFolder != prefabFolder) LazarusImportWatcher.SetPrefabFolder(newFolder);
    }

    void HandleDragAndDrop()
    {
        Event evt = Event.current;
        Rect dropArea = GUILayoutUtility.GetRect(0, 50, GUILayout.ExpandWidth(true));
        GUI.Box(dropArea, "💟 GameObjects hier rein ziehen", EditorStyles.helpBox);

        if ((evt.type == EventType.DragUpdated || evt.type == EventType.DragPerform) && dropArea.Contains(evt.mousePosition))
        {
            DragAndDrop.visualMode = DragAndDropVisualMode.Copy;
            if (evt.type == EventType.DragPerform)
            {
                DragAndDrop.AcceptDrag();
                foreach (var obj in DragAndDrop.objectReferences)
                    if (obj is GameObject go && !targets.Contains(go)) targets.Add(go);
                evt.Use();
            }
        }
    }

    void DrawPreview()
    {
        GUILayout.Label("🎯 Vorschau: Materialien zur Umwandlung", EditorStyles.boldLabel);
        foreach (var go in targets)
        {
            foreach (var rend in go.GetComponentsInChildren<Renderer>(true))
            {
                foreach (var mat in rend.sharedMaterials)
                {
                    if (mat != null && mat.shader.name != kShaderName)
                        GUILayout.Label("- " + mat.name);
                }
            }
        }
    }

    void AssignAndDuplicateMaterials()
    {
        int changed = 0;
        foreach (var go in targets)
        {
            foreach (var renderer in go.GetComponentsInChildren<Renderer>(true))
            {
                Undo.RecordObject(renderer, "Lazarus Shader Assign");
                Material[] newMats = renderer.sharedMaterials.Select(mat => Convert(mat, ref changed)).ToArray();
                renderer.sharedMaterials = newMats;
                EditorUtility.SetDirty(renderer);
            }
        }
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log("[Lazarus] Materialien verarbeitet: " + changed);
    }

    Material Convert(Material src, ref int changed)
    {
        if (src == null || src.shader.name == kShaderName) return src;

        Material newMat = new Material(lazarusShader) { name = src.name + "_Lazarus" };
        CopyAll(src, newMat);
        SetAverageTintFromTexture(src, newMat);
        string path = GenerateUniquePath(src);
        AssetDatabase.CreateAsset(newMat, path);
        AssetDatabase.ImportAsset(path);
        EditorUtility.SetDirty(newMat);

        changed++;
        return newMat;
    }

    void CopyAll(Material from, Material to)
    {
        CopyTex(from, to, "_MainTex", "_MainTex");
        CopyCol(from, to, "_Color", "_Color");
        bool metalTex = CopyTex(from, to, "_MetallicGlossMap", "_MetallicTex");
        if (!metalTex) CopyFloat(from, to, "_Metallic", "_Metallic");
        CopyFloat(from, to, "_Glossiness", "_Roughness", true);
        bool normalTex = CopyTex(from, to, "_BumpMap", "_NormalTex");
        bool emisTex = CopyTex(from, to, "_EmissionMap", "_EmissionTex");
        CopyCol(from, to, "_EmissionColor", "_EmissionColor");

        if (to.HasProperty("_UseAlbedoTex")) to.SetFloat("_UseAlbedoTex", to.GetTexture("_MainTex") ? 1 : 0);
        if (to.HasProperty("_UseNormalTex")) to.SetFloat("_UseNormalTex", normalTex ? 1 : 0);
        if (to.HasProperty("_UseMetallicTex")) to.SetFloat("_UseMetallicTex", metalTex ? 1 : 0);
        if (to.HasProperty("_UseEmissionTex")) to.SetFloat("_UseEmissionTex", emisTex ? 1 : 0);
        if (to.HasProperty("_EmissionToggle")) to.SetFloat("_EmissionToggle", emisTex ? 1 : 0);
    }

    void SetAverageTintFromTexture(Material from, Material to)
    {
        Texture2D tex = from.GetTexture("_MainTex") as Texture2D;
        if (tex == null || !to.HasProperty("_TexColorTint")) return;

        string path = AssetDatabase.GetAssetPath(tex);
        TextureImporter importer = AssetImporter.GetAtPath(path) as TextureImporter;
        if (importer != null && !importer.isReadable)
        {
            importer.isReadable = true;
            importer.textureCompression = TextureImporterCompression.Uncompressed;
            importer.SaveAndReimport();
        }

        Color[] pixels = tex.GetPixels();
        if (pixels.Length == 0) return;

        Color sum = Color.black;
        foreach (Color c in pixels)
            sum += c;

        Color avg = sum / pixels.Length;

        // Optional: leicht aufhellen
        avg = new Color(
            Mathf.Clamp01(avg.r + 0.2f),
            Mathf.Clamp01(avg.g + 0.2f),
            Mathf.Clamp01(avg.b + 0.2f),
            1);

        to.SetColor("_TexColorTint", avg);
    }

    bool CopyTex(Material from, Material to, string fromProp, string toProp)
    {
        if (from.HasProperty(fromProp) && to.HasProperty(toProp))
        {
            Texture tex = from.GetTexture(fromProp);
            if (tex != null)
            {
                to.SetTexture(toProp, tex);

                if (toProp == "_NormalTex")
                {
                    string texPath = AssetDatabase.GetAssetPath(tex);
                    var imp = AssetImporter.GetAtPath(texPath) as TextureImporter;
                    if (imp != null && imp.textureType != TextureImporterType.NormalMap)
                    {
                        imp.textureType = TextureImporterType.NormalMap;
                        imp.SaveAndReimport();
                    }
                }
                return true;
            }
        }
        return false;
    }

    void CopyCol(Material from, Material to, string fromProp, string toProp)
    {
        if (from.HasProperty(fromProp) && to.HasProperty(toProp))
            to.SetColor(toProp, from.GetColor(fromProp));
    }

    void CopyFloat(Material from, Material to, string fromProp, string toProp, bool invert = false)
    {
        if (from.HasProperty(fromProp) && to.HasProperty(toProp))
        {
            float val = from.GetFloat(fromProp);
            to.SetFloat(toProp, invert ? 1f - val : val);
        }
    }

    string GenerateUniquePath(Material src)
    {
        string srcPath = AssetDatabase.GetAssetPath(src);
        string folder = string.IsNullOrEmpty(srcPath) ? "Assets" : Path.GetDirectoryName(srcPath);
        string name = src.name + "_Lazarus.mat";
        return AssetDatabase.GenerateUniqueAssetPath(Path.Combine(folder, name).Replace("\\", "/"));
    }
}
